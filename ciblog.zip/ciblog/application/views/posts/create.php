<h2><?= $title; ?></h2>
<?php echo validation_errors(); ?>
<div class="row">
	<?php echo form_open_multipart('posts/create');?>
	<div class="row">
		<div class="input-field col s12">
			<input type="text" id="title" name="title" class="validate">
			<label for="title">Add Title</label>
		</div>
		<!-- title -->

		<!-- file upload -->
		<div class="file-field input-field col s12">

			<div class="btn">
				<span>Input Image <i class="material-icons right">attach_file</i></span>
				<input type="file" name="userfile" size="20">
			</div>
			<div class="file-path-wrapper">
				<input class="file-path validate" type="text">
			</div>	

		</div>

		<div class="input-field col s12">
			<p>Add Body</p>
			<textarea id="body" name="body" class="materialize-textarea"></textarea>
		</div>

		<div class="input-field col s12">
			<select name="category_id" multiple>
				<option value="" disabled>Select Category</option>
					<?php foreach($categories as $category): ?>
					<option value="<?php echo $category['id']; ?>"><?php echo $category['name']; ?></option>
				<?php endforeach; ?>
			</select>
			<label>Category</label>
		</div>
		<div class="input-field col s12">
			<button class="btn waves-effect waves-light" type="submit" name="action">Submit<i class="material-icons right">send</i></button>
		</div>
	</div>
	</form>
</div>
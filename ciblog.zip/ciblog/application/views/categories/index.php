<div class="row">
    <div class="col s12">    
        <h2 class="teal-text"><?= $title ?> : </h2>
    </div>
</div>

<div class="row">
    <div class="col s12">
        <div class="collection z-depth-2">
            <?php foreach($categories as $category) : ?>
            <li class="collection-item"><div><a href="<?php echo site_url('/categories/posts/'.$category['id']); ?>" class="waves-effect waves-light teal-text"><?php echo $category['name']; ?></a>
            <?php if($this->session->userdata('user_id') == $category['user_id']) : ?>
                <form action="categories/delete/<?php echo $category['id']; ?>" method="POST" class="category-button">
                    <div class="input-field">
                        <button class="btn waves-effect waves-light red" type="submit" name="action" >Delete<i class="material-icons right">close</i></button>
                    </div>
                </form>    
            <?php endif; ?>
            </div></li>
            <?php endforeach; ?>
        </div>
    </div>
</div>
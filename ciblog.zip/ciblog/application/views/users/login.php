<?php echo form_open('users/login') ?>
    <div class="row">
        <div class="col s4 offset-s4 login-form z-depth-2">

            <h2 class="teal-text" ><?= $title; ?></h2>

            <div class="input-field">
                <input type="text" id="username" name="username" class="validate">
                <label for="username">User Name</label>
            </div>

            <div class="input-field">
                <input type="password" id="password" name="password" class="validate">
                <label for="password">password</label>
            </div>
            
            <div class="input-field">
                <button class="btn waves-effect waves-light" type="submit" name="action">login<i class="material-icons right">person</i></button>
            </div>

        </div>
    </div>
<?php echo form_close(); ?>
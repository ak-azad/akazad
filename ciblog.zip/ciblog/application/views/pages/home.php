
    <div class="row">
        <div class="col s12">
            <h1><?= $title; ?></h1>
            <p>Welcome to ciBlog application</p>
        </div>
    </div>
 
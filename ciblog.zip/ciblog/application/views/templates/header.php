<!DOCTYPE html>
<html>
	<head>
		<title>CIBLOG</title>
		<!--Import Google Icon Font-->
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<!--Import materialize.css-->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
		<!-- custom css file -->
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
		<!--Let browser know website is optimized for mobile-->
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	</head>
	<body>
		<!-- Navbar -->
		<div class="navbar-fixed">
			<nav>
				<div class="nav-wrapper">
					<a href="<?php echo base_url();?>" class="brand-logo" style="padding-left: 20px;"><span class="yellow-text text-accent-4">C</span><span class="yellow-text text-darken-2">I</span><span class="yellow-text text-accent-4">B</span><span class="yellow-text text-darken-2">LOG</span></a>
					<a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
					<ul class="right hide-on-med-and-down" style="padding-right: 20px;">
						<li><a href="<?php echo base_url();?>">Home</a></li>
						<li><a href="<?php echo base_url();?>/about">About</a></li>
						<li><a href="<?php echo base_url();?>posts">Blog</a></li>
						<li><a href="<?php echo base_url();?>categories">Categories</a></li>
						<li><a href="<?php echo base_url();?>users/register">Sign Up</a></li>
						<li><a href="<?php echo base_url();?>users/login">login</a></li>
						<span class="owner">
							<?php if($this->session->userdata('logged_in')) : ?>
								<li>|</li>
								<li><a href="<?php echo base_url();?>posts/create">Create Post</a></li>
								<li><a href="<?php echo base_url();?>categories/create">Create Categories</a></li>
								<li><a href="<?php echo base_url();?>users/logout">log out</a></li>
							<?php endif; ?>
						</span>
					</ul>
				</div>
			</nav>
		</div>
		<ul class="sidenav" id="mobile-demo">
			<ul>
				<li class="close-nav"><a href=""><i class="material-icons red-text">close</i></a></li>
			</ul>
			<li><a href="<?php echo base_url();?>">Home</a></li>
			<li><a href="<?php echo base_url();?>about">About</a></li>
			<li><a href="<?php echo base_url();?>posts">Blog</a></li>
			<li><a href="<?php echo base_url();?>categories">Categories</a></li>
			<li><a href="<?php echo base_url();?>users/register">Sign Up</a></li>
			<li><a href="<?php echo base_url();?>users/login">login</a></li>
			<span class="owner">
				<?php if($this->session->userdata('logged_in')) : ?>
					<li><a href="<?php echo base_url();?>posts/create">Create Post</a></li>
					<li><a href="<?php echo base_url();?>categories/create">Create Categories</a></li>
					<li><a href="<?php echo base_url();?>users/logout">log out</a></li>
				<?php endif; ?>
			</span>
		</ul>
		<!-- main container --> 
		<div class="my-content" style="width: 98%;margin: 0 auto;">
			<div class="container">
				<div class="row">
					<div class="col s12 success">
						<!-- flash massages -->
						<?php if($this->session->flashdata('user_registered')): ?>
							<?php echo '<p class="teal white-text">'.$this->session->flashdata('user_registered').'</p>' ?>
						<?php endif; ?>

						<?php if($this->session->flashdata('post_created')): ?>
							<?php echo '<p class="teal white-text">'.$this->session->flashdata('post_created').'</p>' ?>
						<?php endif; ?>

						<?php if($this->session->flashdata('post_updated')): ?>
							<?php echo '<p class="teal white-text">'.$this->session->flashdata('post_updated').'</p>' ?>
						<?php endif; ?>

						<?php if($this->session->flashdata('category_created')): ?>
							<?php echo '<p class="teal white-text">'.$this->session->flashdata('category_created').'</p>' ?>
						<?php endif; ?>

						<?php if($this->session->flashdata('post_deleted')): ?>
							<?php echo '<p class="teal white-text">'.$this->session->flashdata('post_deleted').'</p>' ?>
						<?php endif; ?>

						<?php if($this->session->flashdata('login_failed')): ?>
							<?php echo '<p class="red white-text z-depth-2">'.$this->session->flashdata('login_failed').'</p>' ?>
						<?php endif; ?>
						
						<?php if($this->session->flashdata('user_loggedin')): ?>
							<?php echo '<p class="teal white-text">'.$this->session->flashdata('user_loggedin').'</p>' ?>
						<?php endif; ?>

						<?php if($this->session->flashdata('user_loggedout')): ?>
							<?php echo '<p class="teal white-text">'.$this->session->flashdata('user_loggedout').'</p>' ?>
						<?php endif; ?>

						<?php if($this->session->flashdata('category_deleted')): ?>
							<?php echo '<p class="teal white-text">'.$this->session->flashdata('category_deleted').'</p>' ?>
						<?php endif; ?>

					</div>
				</div>
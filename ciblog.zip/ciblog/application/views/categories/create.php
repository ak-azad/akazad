<div class="row">
    <div class="col s12">    
        <h2 class="teal-text"><?= $title ?> : </h2>
    </div>
</div>

<?php echo validation_errors(); ?>

<?php echo form_open_multipart('categories/create'); ?>

    <div class="row">
        <div class="input-field col s12">
            <input type="text" class="validate" name="name" placeholder="Enter Category Name">
            <label for="name">Name</label>
        </div>
    </div>

    <div class="row">
        <div class="input-field col s12">
            <button class="btn waves-effect waves-light" type="submit" name="action">Submit<i class="material-icons right">send</i></button>
        </div>
    </div>
</form>
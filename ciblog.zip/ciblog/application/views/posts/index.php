<div class="row">
    <div class="col s12">    
        <h1 class="teal-text"><?= $title ?> : </h1>
    </div>
</div>

<?php foreach($posts as $post) : ?>

        <div class="row z-depth-2" style="padding: 0 22px 40px 26px;">

            <div class="col s12">
                <h3 class="teal-text"><?php echo $post['title']; ?></h3>
                <span class="post-date teal-text text-darken-4 teal lighten-4"><?php echo $post['created_at']; ?> in <strong><?php echo $post['name']; ?></strong></span><br/>
            </div>

            <div class="col s4">
                <img class="materialboxed responsive-img post-image" src="<?php echo site_url()?>assets/images/posts/<?php echo $post['post_image'];?>">
            </div>

            <div class="col s8">
                <p><?php echo word_limiter($post['body'], 100); ?></p>
                <a href="<?php echo site_url('/post/'.$post['slug']); ?>" class="waves-effect waves-light btn">read more</a>
            </div>

        </div>

<?php endforeach; ?>
<div class="row">
    <div class="col s12">
        <ul class="pagination">
            <?php echo $this->pagination->create_links(); ?>
        </ul>    
    </div>
</div>
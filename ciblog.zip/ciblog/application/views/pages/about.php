<div class="row">
  <div class="col s12">
    <h1><?= $title; ?></h1>
    <p>This is ciBlog version 1.0</p>
  </div>
</div>
  
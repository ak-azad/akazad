<div class="z-depth-2 view_post">

	<div class="row">
		<div class="col s12">
			<h2 class="teal-text" ><?php echo $posts['title']; ?></h2>
			<span class="post-date teal-text text-darken-4 teal lighten-4"><?php echo $posts['created_at']; ?></span><br/>
		</div> 
		
		<div class="col s4">
            <img class="materialboxed responsive-img" src="<?php echo site_url()?>assets/images/posts/<?php echo $posts['post_image'];?>">
        </div>

		<div class="col s12">
			<div class="post-body">
				<?php echo $posts['body'] ?>
			</div>
		</div>
	</div>


	<div class="row">
		<?php if($this->session->userdata('user_id') == $posts['user_id']) : ?>
		<div class="col s6 m6 l6" style="margin-left: -12px;">
			<?php echo form_open('posts/delete/'.$posts['id']);?>
			<div class="input-field">
				<button class="btn waves-effect waves-light red" type="submit" name="action">Delete<i class="material-icons right">close</i></button>
			</div>
			</form>
		</div>

		<div class="col s6 m3 pull-m2 pull-l4" style="margin: 15px 0 0 0;">
			<a class="btn waves-effect waves-light teal" href="<?php echo base_url(); ?>posts/edit/<?php echo $posts['slug']; ?>" >Edit<i class="material-icons right">edit</i></a>
		</div>
		<?php endif; ?>
	</div>

	<div class="row">
		<div class="col s12">
			<h3 class="teal-text" >Comments</h3>
		</div>
		<div class="col s12 teal-text">
			<div class="comment">
				<?php if($comments) : ?>

					<?php foreach($comments as $comment) : ?>
						<span><?php echo $comment['body']; ?> [by <span class="red-text"> <strong> <?php echo $comment['name']; ?> </strong></span> ] </span>
					<?php endforeach; ?>

				<?php else : ?>
					<p>no comments to display</p>
				<?php endif; ?>
			</div> 
		</div> 
	</div>	

	<div class="row">
		<div class="col s12">
			<h3 class="teal-text">Add Comment</h3>
		</div>
	</div>

	<?php echo validation_errors(); ?>
	<?php echo form_open('comments/create/'.$posts['id']); ?>
		<div class="row">
			<div class="col s12">
					
				<div class="input-field col s12">
					<p>Name</p>
					<input type="text" id="name" name="name" class="validate">
				</div>

				<div class="input-field col s12">
					<p>email</p>
					<input type="text" id="email" name="email" class="validate">
				</div>

				<div class="col s12">
					<div class="input-field">
						<p>Comment</p>
						<textarea id="body" name="body" class="validate"></textarea>
					</div>
				</div>

				<input type="hidden" name="slug" value="<?php echo $posts['slug']; ?>"

				<div class="input-field col s12">
					<button class="btn waves-effect waves-light" type="submit" name="action">Submit<i class="material-icons right">send</i></button>
				</div>

			</div>
		</div>
	</form>

</div>
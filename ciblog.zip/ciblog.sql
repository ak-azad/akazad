-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 08, 2019 at 11:57 AM
-- Server version: 5.7.26-0ubuntu0.18.10.1
-- PHP Version: 7.2.19-0ubuntu0.18.10.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ciblog`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `user_id`, `name`, `created_at`) VALUES
(3, 1, 'Bussiness', '2019-08-27 11:17:57'),
(4, 2, 'Technology', '2019-08-27 11:17:57'),
(5, 1, 'Movie', '2019-08-31 13:52:24'),
(6, 2, 'Story', '2019-08-31 19:06:33');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `name`, `email`, `body`, `created_at`) VALUES
(0, 21, 'ashikur', 'kalamdipbcmc@gmail.com', '<p>this is simple comment</p>', '2019-09-02 06:56:35'),
(0, 20, 'Ashiqur Rahaman (Shykot)', 'bipulhstu@gmail.com', '<p>In order to install Fat Free Framework, we don&rsquo;t need composer, but it is a good idea to use composer because we need to think about the good things coming from it, like loading additional libraries, or updating the framework and/or libraries.</p>', '2019-09-02 06:58:40'),
(0, 20, 'Aslam Khan', 'jasimuddindxn@gmail.com', '<p>In order to install Fat Free Framework, we don&rsquo;t need composer, but it is a good idea to use composer because we need to think about the good things coming from it, like loading additional libraries, or updating the framework and/or libraries.</p>', '2019-09-02 07:02:19'),
(0, 18, 'Ahmed Quamrul Millat Kabir', 'kawsar.ns@gmail.com', '<p>Thank you for you many fine tutorials, especially on the use of CodeIgniter.<br />Your article on Fat-Free Framework, which I had never tried before, prompts me to ask a few questions:<br />1. The CodeIgniter forum for Version 4 indicates that V.4 will require complete code re-writes. Does it make sense to commit a lot of time using V.3 for a major new project?<br />2. Some of the CI features, such as form validation rules for example, can be handled with HTML 5 and JavaScript. Is it not more efficient (and only slightly harder) to use these client-side methods when available?<br />3. For someone reasonably competent in writing PHP code and MySQL queries, do you think that the Fat-Free Framework might be a better choice for long-term stability? (I realize there is no definitive answer to this, but I am interested in your general opinion.)<br />Thanks,<br />RHF</p>', '2019-09-02 07:07:08'),
(0, 21, 'Bipul Islam', 'kingsuinin@outlook.com', '<p>Storyline After a lonely summer on Privet Drive, <strong>Harry</strong> returns to a Hogwarts full of ill fortune. Few of students and parents believe him or Dumbledore that Voldemort is ...to be the nastiest person <strong>Harry</strong> has ever encountered. <strong>Harry</strong> also can\'t help stealing glances with the beautiful Cho Chang.</p>', '2019-09-02 08:05:20'),
(0, 19, 'Blaack Mirror', 'likhon_imaginemail@yahoo.com', '<p>Building from an amateur to supporting yourself with performing is no easy task, many performers never go beyond it being a side job to bring in some extra income. Putting a roof over your head and food in your belly entirely with entertaining is a bit scary. You would be well advised to put aside a chunk of savings to help keep your bills paid for a time as you are making the transition. Doing table hopping (if you perform closeup magic) is a good way to supplement private shows and pick up gigs. You can even earn your main income from this with private shows being the filler if you appear enough nights per week at various establishments and you are not under-charging these bars or restaurants for your services.</p>', '2019-09-02 08:06:51'),
(0, 17, 'bristi', 'rajibdewanbd@g­mail.com', '<p>London based hit men Ray and Ken are told by their boss <strong>Harry</strong> Waters to lie low in Bruges, Belgium for up to two weeks following their latest hit, which resulted in the ... <strong>Harry</strong> will be in touch with further instructions. While they wait for <strong>Harry</strong>\'s call, Ken, following <strong>Harry</strong>\'s advice, takes ...</p>', '2019-09-02 08:13:36'),
(0, 17, 'bukacuda', 'ice05alamin@gmail.co­m', '<p>For &ldquo;someone reasonably competent in writing PHP&rdquo;, the best of the best solution would be to use no framework at all. Fat-Free Framework is the closest thing to a &ldquo;no frame at all&rdquo; idea, but the thing is that when using no framework or even F3 you will find yourself in front of a blank page&hellip; And this is scary&hellip; CodeIgniter on the other hand has almost everything you need, so you won&rsquo;t have to think too much in order to put a website online. You should find an equilibrium between the time you can afford to spend and the task you have to do.</p>', '2019-09-02 08:14:22');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `post_image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `category_id`, `user_id`, `title`, `slug`, `body`, `post_image`, `created_at`) VALUES
(17, 4, 1, 'Harry Potter and the Chamber of Secrets (2002)', 'Harry-Potter-and-the-Chamber-of-Secrets-2002', '<p>Storyline Forced to spend his summer holidays with his muggle relations, <strong>Harry</strong> Potter gets a real shock when he gets a surprise visitor: Dobby the house elf, who warns <strong>Harry</strong> Potter against returning to Hogwarts</p>', 'bindweed-corridor-flora-59599.jpg', '2019-08-30 21:05:23'),
(18, 3, 1, 'Material Box', 'Material-Box', '<p>Material box is a material design implementation of the Lightbox plugin. When a user clicks on an image that can be enlarged, Material box centers the image and enlarges it in a smooth, non-jarring manner. To dismiss the image, the user can either click on the image again, scroll away, or press the ESC key.</p>\r\n<p>&nbsp;</p>\r\n<p>Because jQuery is no longer a dependency, all the methods are called on the plugin instance. You can get the plugin instance like this:</p>\r\n<p>&nbsp;</p>\r\n<p>Our slider is a simple and elegant image carousel. You can also have captions that will be transitioned on their own depending on their alignment. You can also have indicators that show up on the bottom of the slider.</p>\r\n<p>Because jQuery is no longer a dependency, all the methods are called on the plugin instance. You can get the plugin instance like this:</p>\r\n<p>We hope you have enjoyed using Materialize and if you feel like it has helped you out and want to support the team you can help us by donating or backing us on Patreon. Any amount would help support and continue development on this project and is greatly appreciated.</p>', 'kalam1.jpg', '2019-08-31 04:38:28'),
(19, 4, 2, 'Can I become a real magician?', 'Can-I-become-a-real-magician', '<p>Learn a few a tricks and practice them endlessly. Resist the urge to try to learn a dozen tricks all at once. Just start by mastering one or two and gradually add tricks to your repertoire. Concentrate on being entertaining, not just fooling people. Incorporate your personality into your magic - don&rsquo;t try to do comedy if you are a normally serious person, don&rsquo;t try to be mysterious if you are 12 years old or like to crack jokes all day long.<br /><br />Slowly build up a short act of three or four tricks and perform it as often as you can, then add new material. Once you have an act and can do a solid 15 or 20 minutes and keep an audience engaged and entertained, you should be able to find plenty of charities that would enjoy a show but don&rsquo;t have the money to hire a pro. This is your chance to perform in front of people who are not your family and friends and learn how to keep a show moving and interesting for complete strangers.<br /><br />Do not charge people a single dime until you have developed to a point where you are giving excellent value for the money spent and you can charge comparable rates to what magic shows are going for in your area. Don&rsquo;t undercut other people, you come off as a cheap sleazy type and you&rsquo;ll quickly lose any friends you&rsquo;ve made in the local magic scene.<br /><br />Building from an amateur to supporting yourself with performing is no easy task, many performers never go beyond it being a side job to bring in some extra income. Putting a roof over your head and food in your belly entirely with entertaining is a bit scary. You would be well advised to put aside a chunk of savings to help keep your bills paid for a time as you are making the transition. Doing table hopping (if you perform closeup magic) is a good way to supplement private shows and pick up gigs. You can even earn your main income from this with private shows being the filler if you appear enough nights per week at various establishments and you are not under-charging these bars or restaurants for your services.</p>', 'kalam2.jpg', '2019-08-31 04:42:39'),
(20, 4, 1, 'How to Be a Magician', 'How-to-Be-a-Magician', '<p>&nbsp;Magic is a fascinating hobby! It is fascinating because it uses dazzling displays and mysterious illusions to captivate audiences of all ages. Because magic is so fascinating, many people want to learn how to be a magician. However, becoming a magician is a big responsibility&mdash;one that requires practice, dedication, and respect. By reading this article, you already have shown an interest in learning magic. Today, I am going to expose you to the underground world of magic, and by the end of this article, you will be well on your way to becoming a great magician.<br /><br />The first thing you need to know about being a magician is that there is a magician\'s code. This code exists to protect the art of magic so that it can continue to dazzle audiences in the years to come. The main points of the magician\'s code are as follows:<br /><br />&nbsp;&nbsp;&nbsp; Practice all tricks thoroughly before performing in front of others<br />&nbsp;&nbsp;&nbsp; Never repeat the same trick twice unless you use a different method for each performance<br />&nbsp;&nbsp;&nbsp; Never expose the secrets to tricks that are currently being sold by other magicians<br />&nbsp;&nbsp;&nbsp; Never tell your secrets to non-magicians<br /><br />If you learn some magic tricks and follow those guidelines, you are welcome to call yourself a magician.<br /><br />The next step in becoming a magician is to understand more about the hobby. Every magic trick you learn can be categorized into an \"effect\" and a \"method.\" The effect of a magic trick is a description of what the trick looks like to the audience. Part of the effect includes possible \"patter\" for the trick. Patter is what you say, as a magician, during the trick to keep your audience interested. Sometimes a trick will have little to no patter\"that can be a good thing under certain circumstances. The method of a magic trick is an explanation of how to do that magic trick. Magic tricks are often composed of \"sleights,\" or special moves/illusions that accomplish a desired effect without the audience\'s knowledge. Some sleights are used quite a bit in magic, and other sleights are used infrequently. Sleights are helpful because they make it easier to explain how to do a particular trick. Most of your time as a magician will initially be spent learning and practicing sleights. Some sleights can take years to master, while others can be learned in a single day. Many sleights accomplish similar things. Some other terms you might hear are \"spectator\" and \"heckler.\" A spectator is anyone who is watching your trick. A heckler is a spectator who is a nuisance. Hecklers often try to mess up a magician, expose a magician\'s secrets, or lessen the amazement of the audience</p>', 'kalam3.jpg', '2019-08-31 04:44:31'),
(21, 6, 1, 'someone who can command supernatural powers', 'someone-who-can-command-supernatural-powers', '<p>Learn a few a tricks and practice them endlessly. Resist the urge to try to learn a dozen tricks all at once. Just start by mastering one or two and gradually add tricks to your repertoire. Concentrate on being entertaining, not just fooling people. Incorporate your personality into your magic - don&rsquo;t try to do comedy if you are a normally serious person, don&rsquo;t try to be mysterious if you are 12 years old or like to crack jokes all day long.<br />Slowly build up a short act of three or four tricks and perform it as often as you can, then add new material. Once you have an act and can do a solid 15 or 20 minutes and keep an audience engaged and entertained, you should be able to find plenty of charities that would enjoy a show but don&rsquo;t have the money to hire a pro. This is your chance to perform in front of people who are not your family and friends and learn how to keep a show moving and interesting for complete strangers.<br />Do not charge people a single dime until you have developed to a point where you are giving excellent value for the money spent and you can charge comparable rates to what magic shows are going for in your area. Don&rsquo;t undercut other people, you come off as a cheap sleazy type and you&rsquo;ll quickly lose any friends you&rsquo;ve made in the local magic scene.<br />Building from an amateur to supporting yourself with performing is no easy task, many performers never go beyond it being a side job to bring in some extra income. Putting a roof over your head and food in your belly entirely with entertaining is a bit scary. You would be well advised to put aside a chunk of savings to help keep your bills paid for a time as you are making the transition. Doing table hopping (if you perform closeup magic) is a good way to supplement private shows and pick up gigs. You can even earn your main income from this with private shows being the filler if you appear enough nights per week at various establishments and you are not under-charging these bars or restaurants for your services.</p>', 'gardentwo.jpg', '2019-08-31 20:41:32'),
(22, 4, 1, 'You’re in a Private Window', 'Youre-in-a-Private-Window', '<p>Firefox clears your search and browsing history when you quit the app or close all Private Browsing tabs and windows. While this doesn&rsquo;t make you anonymous to websites or your internet service provider, it makes it easier to keep what you do online private from anyone else who uses this computer.</p>', 'gardentwo.jpg', '2019-09-04 19:32:44'),
(23, 3, 1, 'Zincum metallicum', 'Zincum-metallicum', '<p><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Zinc. has a full and substantial proving, including symptoms of every part of the body. It is an antipsoric, suitable in broken down constitutions, feeble constitutions; enfeeblement characterizes the whole proving.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The Zinc. patient is nervous and extremely sensitive, excitable, trembling, quivering, twitching of muscles, tearing pain; along the course of the nerves, tingling, excited on the least provocation; over-sensitiveness in one part and lack of feeling in another. This extreme oversensitiveness is like Nux; which is inimical. The overworked and excitable persons belong to Nux and Zinc. Nux &Auml;is sensitive to the higher potencies. Further, there is paralytic weakness, emaciation, prostration; full of brain and spinal symptoms.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; All the functions are slow; eruptions appear slowly. The whole economy seems to be tired and feeble, so that when a girl approaches puberty and it is time for the menses to be established, but the flow does not appear, she goes into a decline; she begins to manifest symptoms, jerking, and twitching, soreness in the back of the neck, burning of the whole spine, creeping and crawling of the extremities, hysterical manifestations of all sorts. Sensitive to every little noise, to people talking in the room, to crumpling of paper. \"Talking or listening is distressing; much talking of other people, even of those of whom he is fond, affects his nerves and makes him morose.\" <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Feeble children, feeble girls, mind feeble, memory poor. Tendency to be docile, but when aroused irascible. If the child comes down with scarlatina or measles, it goes into a stupor. The eruption does not come out. There is a tendency to convulsions, drawing in the extremities, suppression of urine, rolling of the head from one side to the other, and from stupor it goes into complete unconsciousness; inability to throw eruptions to the surface.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The stomach is slow in digesting; sour vomiting. The intestines are sluggish. The rectum becomes impacted. Difficult expulsion of urine; paralysis of the bladder and tedious constipation associated with spinal symptoms; urine slow in starting; can pass it only when sitting and in some cases only when sitting leaning back against the seat with hard pressure. Aching in the dorsal, lumbar, and sacral regions; better when walking and worse from rising from a seat. (In Rhus, the aching is in the sacral region, and better when walking and coming on while sitting. Calc., Rhus., Phos., Sulph. And Sepia have this in the highest degree. Zinc. occupies a lower grade in the aggravation when rising from a seat, as do Petr. and Ledum.)<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Numbness of the soles of the feet, with cutting pain and soreness in the heel when stepping; fulgurating pains, stitching, stabbing, and tearing; tabes dorsalis.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Limbs paralyzed; paresis and finally paralysis of one or both sides; jerking, trembling and prostration. Shocks and jerking during sleep.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Trophic enters in a state of anemia; emaciation throughout the body; the skin looks withered; the face pallid, wrinkled, unhealthy, sickly. Always chilly; sensitive to the cold. Full of neuralgic pains; tearing pains in all parts of the body when exposed to a draft; tension and drawing in various places. Strange drawing about the eyes as if strabismus would come on; drawing in the muscles; neck drawn back; tension and drawing everywhere. When he comes to rest, the limbs want to draw up, hence, hysterical contracture; drawing the fingers all out of shape.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The mind is slow and the patient is weak and tired; weak memory; forgetful. \"Repeats all questions before answering them.\" When an individual does this it is to make the mind comprehend. He must first realize what it means and then answers. Such a symptom is found in typhoid, when the patient does not convalesce; in a child after brain affections. Nervous prostration; waits a moment, looking blank, then the face lights up and he answers. If you look at the Zincum patient and do not address him, you would not realize that he was so weak, but put a question to him and he stares at you in perfect amazement, then says, \"Oh,\" and answers.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Zinc. is not suitable in those who are naturally feeble-minded, when the child is in a state bordering upon idiocy. Baryta carb. feeds such a mind. He rouses out of a semi-slumber and stares a moment without answering. <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Stupor; aroused by every little noise, startles, twitches all over; but soon he goes beyond this, becoming less and less excitable, and finally passes into unconsciousness and cannot be aroused.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; You will find some deep-seated brain troubles that will try your patience. Some cases go slowly and gradually into unconsciousness; rolling of the head for days; eyes lusterless; body emaciated, involuntary discharges of feces and urine in the bed; tongue dry and parched, so shrivelled that it looks like leather, lips also; face withered and each day looks older; paralysis of one hand or one foot, or it seems that the whole muscular system is paralyzed. Screaming out in pain although not so shrilly as in Apis. A dose of Zinc. Will sometimes bring this patient back to life. In a few days after the remedy there will be a jerking and quivering in the parts that were motionless, or its action will be shown in a copious sweat, much vomiting; sudden arousing that is alarming, for it looks like a threatened sinking, but this is the beginning of reaction. Now, for days and nights while this little one is coming back to consciousness, the restoration of sensation in the parts is accompanied with the most tormenting formication, tingling, prickling, creeping, and crawling. The mother and the father and the neighbors will want something done for it, but if you antidote, the case will return to where it was before. This suffering is but the awakening to life. It will go on in this way for a week or two and then will begin to show signs of falling back; it needs another dose of Zinc., which will again be followed by a sweat, vomiting, etc. You will see this in spinal meningitis. The early stage will be that of congestion, and Bell. may palliate, but with the onset of the symptoms enumerated above, Zinc. is the only remedy that will cure. The Bell. case will have flushed face, hot head, rolling of the head, flashing eyes, throbbing carotids. The Bry. case will be docile, stupid, purple, sleepy; ameliorated by quiet. The Helleborus case will exhibit but little fever; cold extremities, tossing of the head, dilated pupils, unconsciousness, can hardly be aroused; rolling head from side to side, but when the reflexes are abolished, Zinc. comes in.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; After the relief from Gels., Bell., or Bry. give Zinc. Rugged little fellows who hang on for weeks in this state, emaciating and unconscious.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; You must take the mother aside and inform her what will happen if the child returns to consciousness. If you do not, you may be turned out of the house. A persons advanced in years cannot stand such an ordeal, but it is astonishing how the little ones can endure the prolonged congestion and inflammation. After scarlet fever and badly treated meningitis; tubercular meningitis. I have carried these severe forms of brain disease through on Phosphorus, which has a picture somewhat like that of Zincum. There is no record of any recovery from tubercular meningitis, but a homeopath can cure some of these cases, though it may take two or three months to go down and come up out of it, with two or three relapses. <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Among the eye symptoms we have a peculiar thickening and opacity of the conjunctiva, which is infiltrated, leathery, has yellow spots on it and the corners are thickened like pterygium. Dunham made a remarkable cure of pterygium. The report of the case in the Guiding Symptoms is as follows: \"Pterygium in right eye just encroaching on cornea; in left eye extending to the pupil from the inner canthus.\"</p>', 'kalam147.jpg', '2019-09-04 19:38:10'),
(24, 5, 1, '  Strabismus after brain troubles.', 'Strabismus-after-brain-troubles', '<p>You must take the mother aside and inform her what will happen if the child returns to consciousness. If you do not, you may be turned out of the house. A persons advanced in years cannot stand such an ordeal, but it is astonishing how the little ones can endure the prolonged congestion and inflammation. After scarlet fever and badly treated meningitis; tubercular meningitis. I have carried these severe forms of brain disease through on Phosphorus, which has a picture somewhat like that of Zincum. There is no record of any recovery from tubercular meningitis, but a homeopath can cure some of these cases, though it may take two or three months to go down and come up out of it, with two or three relapses. <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Among the eye symptoms we have a peculiar thickening and opacity of the conjunctiva, which is infiltrated, leathery, has yellow spots on it and the corners are thickened like pterygium. Dunham made a remarkable cure of pterygium. The report of the case in the Guiding Symptoms is as follows: \"Pterygium in right eye just encroaching on cornea; in left eye extending to the pupil from the inner canthus.\"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; \"Itching and stinging pain in inner angles of eyes with cloudiness of sight. Much burning of the eyes and lids in the morning and in the evening with feeling of dryness and pressure in them.\"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Zinc. has cured distressing thickening of the lids, ectropion and entropion; granular thickening of the lids. In a severe case of entropion where the lashes were playing up and down the ball with lachrymation, great inflammation and redness, Zinc. removed the whole trouble. Violent photophobia; it seems as if the light would blind him. Zinc. And Euphr. are closely related in eye troubles.</p>', 'kalam987.jpg', '2019-09-04 19:47:57'),
(25, 3, 1, 'Constriction of the whole chest in weakly subjects.', 'Constriction-of-the-whole-chest-in-weakly-subjects', '<p>Zinc. has a full and substantial proving, including symptoms of every part of the body. It is an antipsoric, suitable in broken down constitutions, feeble constitutions; enfeeblement characterizes the whole proving.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The Zinc. patient is nervous and extremely sensitive, excitable, trembling, quivering, twitching of muscles, tearing pain; along the course of the nerves, tingling, excited on the least provocation; over-sensitiveness in one part and lack of feeling in another. This extreme oversensitiveness is like Nux; which is inimical. The overworked and excitable persons belong to Nux and Zinc. Nux &Auml;is sensitive to the higher potencies. Further, there is paralytic weakness, emaciation, prostration; full of brain and spinal symptoms.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; All the functions are slow; eruptions appear slowly. The whole economy seems to be tired and feeble, so that when a girl approaches puberty and it is time for the menses to be established, but the flow does not appear, she goes into a decline; she begins to manifest symptoms, jerking, and twitching, soreness in the back of the neck, burning of the whole spine, creeping and crawling of the extremities, hysterical manifestations of all sorts. Sensitive to every little noise, to people talking in the room, to crumpling of paper. \"Talking or listening is distressing; much talking of other people, even of those of whom he is fond, affects his nerves and makes him morose.\" <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Feeble children, feeble girls, mind feeble, memory poor. Tendency to be docile, but when aroused irascible. If the child comes down with scarlatina or measles, it goes into a stupor. The eruption does not come out. There is a tendency to convulsions, drawing in the extremities, suppression of urine, rolling of the head from one side to the other, and from stupor it goes into complete unconsciousness; inability to throw eruptions to the surface.</p>', 'kalam520.jpg', '2019-09-04 19:57:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `zipcode`, `email`, `username`, `password`, `register_date`) VALUES
(1, 'Ariful Islam', '55555', 'kalamdipbcmc@gmail.com', 'kalam', 'd67d8ab4f4c10bf22aa353e27879133c', '2019-09-04 19:22:17'),
(2, 'abul kalam azad', '744441', 'ru.khan309@gmail.co­m', 'sayed', 'd67d8ab4f4c10bf22aa353e27879133c', '2019-09-07 10:26:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<div class="col s12">
	<h2 class="teal-text" ><?= $title; ?></h2>
</div>

<?php echo validation_errors(); ?>

<?php echo form_open('users/register'); ?>

<div class="row register-form z-depth-2">

	<div class="input-field col s12">
        <input type="text" id="name" name="name" class="validate">
        <label for="name">Name</label>
    </div>
    
	<div class="input-field col s12">
        <input type="text" id="zipcode" name="zipcode" class="validate">
        <label for="zipcode">Zipcode</label>
    </div>

    <div class="input-field col s12">
        <input type="text" id="email" name="email" class="validate">
        <label for="email">Email</label>
    </div>

    <div class="input-field col s12">
        <input type="text" id="username" name="username" class="validate">
        <label for="username">User Name</label>
    </div>

    <div class="input-field col s12">
        <input type="password" id="password" name="password" class="validate">
        <label for="password">Password</label>
    </div>

    <div class="input-field col s12">
        <input type="password" id="passwrod2" name="password2" class="validate">
        <label for="password2">Confirm Password</label>
    </div>

    <div class="input-field col s12">
		<button class="btn waves-effect waves-light" type="submit" name="action">Submit<i class="material-icons right">send</i></button>
	</div>

</div>

<?php echo form_close(); ?>
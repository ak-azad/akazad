<h1 class="teal-text"><?= $title ?> : </h1>

<?php echo validation_errors(); ?>
<div class="row">
    <?php echo form_open('posts/update');?>
        <input type="hidden" name="id" value="<?php echo $posts['id']; ?>" />
        <div class="row">

            <div class="input-field col s12">
                <p>Add Title</p>
                <input type="text" value="<?php echo $posts['title']; ?>" id="title" name="title" class="validate">
            </div> <!-- title -->

            <div class="input-field col s12">
                <p>Add Body</p>
                <textarea value="<?php echo $posts['body']; ?>" id="body" name="body" class="materialize-textarea" ></textarea>
            </div> <!-- Body --> 

            <div class="input-field col s12">
                <select name="category_id" multiple>
                    <option value="" disabled>Select Category</option>
                        <?php foreach($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>"><?php echo $category['name']; ?></option>
                    <?php endforeach; ?>
                </select>
			    <label>Category</label>
		    </div>

            <div class="input-field col s12">
                <button class="btn waves-effect waves-light" type="submit" name="action">Submit<i class="material-icons right">send</i></button>
            </div>
            
        </div>
    </form>
</div>
